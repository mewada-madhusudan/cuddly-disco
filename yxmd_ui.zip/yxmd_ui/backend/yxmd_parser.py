"""
YXMD to PySpark Translator - YXMD Parser and Internal Representation Builder

This module provides functionality to parse Alteryx YXMD workflow files (XML-based)
and build an Internal Representation (IR) that can be used for code generation.
"""

import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum


class ToolType(Enum):
    """Enumeration of supported Alteryx tool types."""
    TEXT_INPUT = "AlteryxTextInput"
    INPUT_DATA = "AlteryxInputData"
    SELECT = "AlteryxSelect"
    FILTER = "AlteryxFilter"
    JOIN = "AlteryxJoin"
    UNION = "AlteryxUnion"
    SORT = "AlteryxSort"
    SUMMARIZE = "AlteryxSummarize"
    FORMULA = "AlteryxFormula"
    SAMPLE = "AlteryxSample"
    UNIQUE = "AlteryxUnique"
    CROSSTAB = "AlteryxCrossTab"
    BROWSE = "AlteryxBrowse"
    OUTPUT_DATA = "AlteryxOutputData"
    UNKNOWN = "Unknown"

    @classmethod
    def from_string(cls, tool_id: str) -> "ToolType":
        """Convert a tool ID string to ToolType enum."""
        for member in cls:
            if member.value == tool_id:
                return member
        return cls.UNKNOWN


@dataclass
class Position:
    """Represents the position of a tool on the workflow canvas."""
    x: int
    y: int


@dataclass
class ToolNode:
    """Represents a single tool in the workflow."""
    tool_id: str
    name: str
    tool_type: ToolType
    position: Position
    properties: Dict[str, Any] = field(default_factory=dict)
    configuration: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        return f"ToolNode(name={self.name}, type={self.tool_type.name}, id={self.tool_id})"


@dataclass
class Connection:
    """Represents a connection between two tools."""
    source_tool_id: str
    source_anchor: str
    target_tool_id: str
    target_anchor: str

    def __repr__(self) -> str:
        return f"Connection({self.source_tool_id}:{self.source_anchor} -> {self.target_tool_id}:{self.target_anchor})"


@dataclass
class WorkflowIR:
    """Internal Representation of an Alteryx workflow."""
    name: str
    version: str
    tools: Dict[str, ToolNode] = field(default_factory=dict)
    connections: List[Connection] = field(default_factory=list)

    def add_tool(self, tool: ToolNode) -> None:
        """Add a tool to the workflow."""
        self.tools[tool.tool_id] = tool

    def add_connection(self, connection: Connection) -> None:
        """Add a connection to the workflow."""
        self.connections.append(connection)

    def get_input_tools(self) -> List[ToolNode]:
        """Get all input tools (data sources) in the workflow."""
        input_types = [ToolType.TEXT_INPUT, ToolType.INPUT_DATA]
        return [tool for tool in self.tools.values() if tool.tool_type in input_types]

    def get_output_tools(self) -> List[ToolNode]:
        """Get all output tools in the workflow."""
        return [tool for tool in self.tools.values() if tool.tool_type == ToolType.OUTPUT_DATA]

    def get_downstream_tools(self, tool_id: str) -> List[ToolNode]:
        """Get all tools that receive data from the given tool."""
        downstream = []
        for conn in self.connections:
            if conn.source_tool_id == tool_id:
                downstream.append(self.tools[conn.target_tool_id])
        return downstream

    def get_upstream_tools(self, tool_id: str) -> List[ToolNode]:
        """Get all tools that send data to the given tool."""
        upstream = []
        for conn in self.connections:
            if conn.target_tool_id == tool_id:
                upstream.append(self.tools[conn.source_tool_id])
        return upstream

    def __repr__(self) -> str:
        return f"WorkflowIR(name={self.name}, tools={len(self.tools)}, connections={len(self.connections)})"


class YXMDParser:
    """Parser for Alteryx YXMD workflow files."""

    def __init__(self, yxmd_path: str):
        """Initialize the parser with a YXMD file path."""
        self.yxmd_path = yxmd_path
        self.tree = None
        self.root = None

    def parse(self) -> WorkflowIR:
        """Parse the YXMD file and return the Internal Representation."""
        # Parse XML
        self.tree = ET.parse(self.yxmd_path)
        self.root = self.tree.getroot()

        # Extract workflow metadata
        workflow_ir = self._extract_workflow_metadata()

        # Extract tools
        self._extract_tools(workflow_ir)

        # Extract connections
        self._extract_connections(workflow_ir)

        return workflow_ir

    def _extract_workflow_metadata(self) -> WorkflowIR:
        """Extract workflow name and version from the root element."""
        # Get workflow name from root attributes or default
        name = self.root.get("name", "Untitled Workflow")
        version = self.root.get("alteryx_version", "2024.1")

        return WorkflowIR(name=name, version=version)

    def _extract_tools(self, workflow_ir: WorkflowIR) -> None:
        """Extract all tools from the YXMD file."""
        # Find all Node elements (tools)
        for node_elem in self.root.findall(".//Node"):
            tool_id = node_elem.get("ToolID")
            name = node_elem.get("Name", f"Tool_{tool_id}")

            # Get position
            position_elem = node_elem.find("Position")
            x = int(position_elem.get("x", 0)) if position_elem is not None else 0
            y = int(position_elem.get("y", 0)) if position_elem is not None else 0
            position = Position(x=x, y=y)

            # Get tool type
            tool_type = ToolType.from_string(tool_id)

            # Extract properties
            properties = self._extract_properties(node_elem)

            # Extract configuration
            configuration = self._extract_configuration(node_elem)

            # Create ToolNode
            tool_node = ToolNode(
                tool_id=tool_id,
                name=name,
                tool_type=tool_type,
                position=position,
                properties=properties,
                configuration=configuration,
            )

            workflow_ir.add_tool(tool_node)

    def _extract_properties(self, node_elem: ET.Element) -> Dict[str, Any]:
        """Extract properties from a tool node."""
        properties = {}

        # Find Properties element
        props_elem = node_elem.find("Properties")
        if props_elem is not None:
            for child in props_elem:
                tag = child.tag
                text = child.text or ""
                properties[tag] = text

        return properties

    def _extract_configuration(self, node_elem: ET.Element) -> Dict[str, Any]:
        """Extract configuration from a tool node."""
        configuration = {}

        # Find Configuration element
        config_elem = node_elem.find("Configuration")
        if config_elem is not None:
            for child in config_elem:
                tag = child.tag
                text = child.text or ""
                attribs = child.attrib
                configuration[tag] = {"text": text, "attributes": attribs}

        return configuration

    def _extract_connections(self, workflow_ir: WorkflowIR) -> None:
        """Extract all connections between tools."""
        # Find all Connection elements
        for conn_elem in self.root.findall(".//Connection"):
            origin_elem = conn_elem.find("Origin")
            dest_elem = conn_elem.find("Destination")

            if origin_elem is not None and dest_elem is not None:
                source_tool_id = origin_elem.get("ToolID")
                source_anchor = origin_elem.get("Anchor", "Output")
                target_tool_id = dest_elem.get("ToolID")
                target_anchor = dest_elem.get("Anchor", "Input")

                connection = Connection(
                    source_tool_id=source_tool_id,
                    source_anchor=source_anchor,
                    target_tool_id=target_tool_id,
                    target_anchor=target_anchor,
                )

                workflow_ir.add_connection(connection)

    def print_summary(self, workflow_ir: WorkflowIR) -> None:
        """Print a summary of the parsed workflow."""
        print(f"\n{'='*60}")
        print(f"Workflow: {workflow_ir.name}")
        print(f"Version: {workflow_ir.version}")
        print(f"{'='*60}\n")

        print(f"Tools ({len(workflow_ir.tools)}):")
        for tool_id, tool in workflow_ir.tools.items():
            print(f"  [{tool_id}] {tool.name} ({tool.tool_type.name})")

        print(f"\nConnections ({len(workflow_ir.connections)}):")
        for conn in workflow_ir.connections:
            source_name = workflow_ir.tools[conn.source_tool_id].name
            target_name = workflow_ir.tools[conn.target_tool_id].name
            print(f"  {source_name} -> {target_name}")

        print(f"\nInput Tools:")
        for tool in workflow_ir.get_input_tools():
            print(f"  - {tool.name} ({tool.tool_type.name})")

        print(f"\nOutput Tools:")
        for tool in workflow_ir.get_output_tools():
            print(f"  - {tool.name}")

        print(f"\n{'='*60}\n")


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python yxmd_parser.py <path_to_yxmd_file>")
        sys.exit(1)

    yxmd_file = sys.argv[1]
    parser = YXMDParser(yxmd_file)
    workflow = parser.parse()
    parser.print_summary(workflow)
