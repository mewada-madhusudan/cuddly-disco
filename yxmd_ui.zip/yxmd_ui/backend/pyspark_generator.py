"""
YXMD to PySpark Translator - PySpark Code Generator

This module generates executable PySpark code from the Internal Representation (IR)
of an Alteryx workflow using Jinja2 templates.
"""

from typing import Dict, List, Set, Optional
from yxmd_parser import WorkflowIR, ToolNode, ToolType, Connection
import textwrap
from jinja2 import Environment, FileSystemLoader

# Initialize Jinja2 environment
# Assuming the template is in the same directory as this file
template_loader = FileSystemLoader("yxmdtranslator/backend")
jinja_env = Environment(loader=template_loader, trim_blocks=True, lstrip_blocks=True)


class PySparKCodeGenerator:
    """Generates PySpark code from a workflow IR."""

    def __init__(self, workflow_ir: WorkflowIR, input_files: Dict[str, str], spark_app_name: Optional[str] = None):
        """Initialize the code generator with a workflow IR and input file paths."""
        self.workflow_ir = workflow_ir
        self.dataframe_vars = {}  # Maps tool_id to DataFrame variable name
        self.input_files = input_files  # Maps tool_id to S3 URI
        self.spark_app_name = spark_app_name if spark_app_name else workflow_ir.name
        self.template = jinja_env.get_template("pyspark_template.jinja2")

    def generate(self) -> str:
        """Generate the complete PySpark code."""
        input_loading_code = self._generate_input_loading()
        transformation_code = self._generate_transformations()
        output_writing_code = self._generate_output_writing()

        return self.template.render(
            workflow_name=self.workflow_ir.name,
            version=self.workflow_ir.version,
            spark_app_name=self.spark_app_name,
            input_loading_code=input_loading_code,
            transformation_code=transformation_code,
            output_writing_code=output_writing_code
        )

    def _get_dataframe_var_name(self, tool_id: str) -> str:
        """Get the variable name for a tool's output DataFrame."""
        if tool_id not in self.dataframe_vars:
            # Use a safe, descriptive name
            tool_name = self.workflow_ir.tools[tool_id].name.replace(" ", "_").replace("-", "_")
            self.dataframe_vars[tool_id] = f"df_{tool_name}_{tool_id}"
        return self.dataframe_vars[tool_id]

    def _generate_input_loading(self) -> str:
        """Generate code to load input data from files."""
        input_tools = self.workflow_ir.get_input_tools()
        code_lines = []

        if not input_tools:
            code_lines.append("\n# No input tools found in workflow\n")
            return "\n".join(code_lines)

        code_lines.append("\n# Load input data")
        code_lines.append("# " + "=" * 60)

        for tool in input_tools:
            var_name = self._get_dataframe_var_name(tool.tool_id)
            self.dataframe_vars[tool.tool_id] = var_name

            if tool.tool_type in [ToolType.TEXT_INPUT, ToolType.INPUT_DATA]:
                code = self._generate_input_code(tool, var_name)
            else:
                code = f"# Unsupported input tool: {tool.tool_type.name}\n"

            code_lines.append(code)
        
        return "\n".join(code_lines)

    def _generate_input_code(self, tool: ToolNode, var_name: str) -> str:
        """Generate code for Input Data and Text Input tools using the provided S3 URI."""
        file_path = self.input_files.get(tool.tool_id)

        if not file_path:
            return f"# WARNING: Input file path not provided for Tool {tool.tool_id} ({tool.name})\n"

        # Determine format based on tool type (simplified assumption)
        if tool.tool_type == ToolType.TEXT_INPUT:
            # Assuming CSV for Text Input
            return f"""{var_name} = spark.read.csv(
    path="{file_path}",
    header=True,
    inferSchema=True,
    sep=","
)
"""
        elif tool.tool_type == ToolType.INPUT_DATA:
            # Assuming Parquet for Input Data
            return f"""{var_name} = spark.read.format("parquet") \\
    .load("{file_path}")
"""
        else:
            return f"# WARNING: Tool {tool.tool_id} ({tool.name}) is not a recognized input tool type.\n"

    # Removed old _generate_text_input_code and _generate_input_data_code


    def _generate_transformations(self) -> str:
        """Generate code for all transformation tools."""
        # Process tools in topological order
        processed = set()
        input_tool_ids = {tool.tool_id for tool in self.workflow_ir.get_input_tools()}
        code_lines = []

        code_lines.append("\n# Apply transformations")
        code_lines.append("# " + "=" * 60)

        # Simple topological sort logic (can be improved)
        all_tool_ids = set(self.workflow_ir.tools.keys())
        
        # Start with input tools
        for tool_id in input_tool_ids:
            processed.add(tool_id)

        # Iteratively process tools whose upstream dependencies are met
        while len(processed) < len(all_tool_ids):
            progress = False
            for tool_id, tool in self.workflow_ir.tools.items():
                if tool_id in processed:
                    continue

                # Check if all upstream tools are processed
                upstream = self.workflow_ir.get_upstream_tools(tool_id)
                if not all(t.tool_id in processed for t in upstream):
                    continue

                # Skip output tools (handled separately)
                if tool.tool_type == ToolType.OUTPUT_DATA:
                    processed.add(tool_id)
                    progress = True
                    continue

                # Generate transformation code
                code = self._generate_tool_code(tool)
                if code:
                    code_lines.append(code)

                processed.add(tool_id)
                progress = True
            
            if not progress and len(processed) < len(all_tool_ids):
                # Handle cycles or tools with unmet dependencies (e.g., missing input tools)
                unprocessed_tools = all_tool_ids - processed
                code_lines.append("\n# WARNING: Could not process all tools (possible cycle or missing input):")
                for tool_id in unprocessed_tools:
                    code_lines.append(f"# - Tool {tool_id}: {self.workflow_ir.tools[tool_id].name}")
                break

        return "\n".join(code_lines)

    def _generate_tool_code(self, tool: ToolNode) -> str:
        """Generate code for a specific tool based on its type."""
        var_name = self._get_dataframe_var_name(tool.tool_id)
        upstream = self.workflow_ir.get_upstream_tools(tool.tool_id)

        if not upstream:
            return f"# {var_name} = <NO_INPUT_DATA> # Tool: {tool.name}\n"

        # For most tools, the input is the first upstream DataFrame
        input_var = self._get_dataframe_var_name(upstream[0].tool_id)

        if tool.tool_type == ToolType.SELECT:
            return self._generate_select_code(tool, var_name, input_var)
        elif tool.tool_type == ToolType.FILTER:
            return self._generate_filter_code(tool, var_name, input_var)
        elif tool.tool_type == ToolType.FORMULA:
            return self._generate_formula_code(tool, var_name, input_var)
        elif tool.tool_type == ToolType.JOIN:
            return self._generate_join_code(tool, var_name, upstream)
        elif tool.tool_type == ToolType.UNION:
            return self._generate_union_code(tool, var_name, upstream)
        elif tool.tool_type == ToolType.SORT:
            return self._generate_sort_code(tool, var_name, input_var)
        elif tool.tool_type == ToolType.SUMMARIZE:
            return self._generate_summarize_code(tool, var_name, input_var)
        elif tool.tool_type == ToolType.UNIQUE:
            return self._generate_unique_code(tool, var_name, input_var)
        elif tool.tool_type == ToolType.SAMPLE:
            return self._generate_sample_code(tool, var_name, input_var)
        elif tool.tool_type == ToolType.BROWSE:
            return self._generate_browse_code(tool, var_name, input_var)
        else:
            return f"# {var_name} = {input_var}  # {tool.tool_type.name} not yet implemented. Tool: {tool.name}\n"

    # --- Tool-specific code generation methods (simplified for brevity) ---

    # Removed _extract_text_input_path as the UI now provides the path

    def _extract_select_columns(self, tool: ToolNode) -> List[str]:
        """Placeholder for extracting selected columns."""
        # In a real implementation, this would parse the XML configuration
        return ["Col1", "Col2"]

    def _extract_filter_condition(self, tool: ToolNode) -> Optional[str]:
        """Placeholder for extracting filter condition."""
        # In a real implementation, this would parse the XML configuration
        return tool.configuration.get("Expression", {}).get("text")

    def _extract_formulas(self, tool: ToolNode) -> Dict[str, str]:
        """Placeholder for extracting formulas."""
        # In a real implementation, this would parse the XML configuration
        return {"NewCol": "col('ExistingCol') * 2"}

    def _extract_join_keys(self, tool: ToolNode) -> List[str]:
        """Placeholder for extracting join keys."""
        # In a real implementation, this would parse the XML configuration
        return ["KeyCol"]

    def _extract_sort_columns(self, tool: ToolNode) -> List[str]:
        """Placeholder for extracting sort columns."""
        # In a real implementation, this would parse the XML configuration
        return ["SortCol"]

    def _extract_group_by_columns(self, tool: ToolNode) -> List[str]:
        """Placeholder for extracting group by columns."""
        # In a real implementation, this would parse the XML configuration
        return ["GroupCol"]

    def _extract_aggregations(self, tool: ToolNode) -> Dict[str, str]:
        """Placeholder for extracting aggregations."""
        # In a real implementation, this would parse the XML configuration
        return {"Count": "count(*)"}

    def _generate_select_code(self, tool: ToolNode, var_name: str, input_var: str) -> str:
        """Generate code for Select tool (column selection/renaming)."""
        columns = self._extract_select_columns(tool)
        cols_str = ", ".join([f'"{col}"' for col in columns])
        return f"{var_name} = {input_var}.select({cols_str})\n"

    def _generate_filter_code(self, tool: ToolNode, var_name: str, input_var: str) -> str:
        """Generate code for Filter tool."""
        condition = self._extract_filter_condition(tool)
        if not condition:
            condition = "lit(True)" # Default to True if no condition is found
        return f"{var_name} = {input_var}.filter({condition})\n"

    def _generate_formula_code(self, tool: ToolNode, var_name: str, input_var: str) -> str:
        """Generate code for Formula tool (computed columns)."""
        formulas = self._extract_formulas(tool)
        code = f"{var_name} = {input_var}\n"
        for col_name, expression in formulas.items():
            code += f'{var_name} = {var_name}.withColumn("{col_name}", {expression})\n'
        return code

    def _generate_join_code(self, tool: ToolNode, var_name: str, upstream: List[ToolNode]) -> str:
        """Generate code for Join tool."""
        if len(upstream) < 2:
            return f"# {var_name} = <INSUFFICIENT_INPUTS> # Tool: {tool.name}\n"
        left_var = self._get_dataframe_var_name(upstream[0].tool_id)
        right_var = self._get_dataframe_var_name(upstream[1].tool_id)
        join_keys = self._extract_join_keys(tool)
        join_keys_str = ", ".join([f'"{key}"' for key in join_keys])
        return f"""{var_name} = {left_var}.join(
    {right_var},
    on=[{join_keys_str}],
    how="inner"
)
"""

    def _generate_union_code(self, tool: ToolNode, var_name: str, upstream: List[ToolNode]) -> str:
        """Generate code for Union tool."""
        if len(upstream) < 2:
            return f"# {var_name} = <INSUFFICIENT_INPUTS> # Tool: {tool.name}\n"
        input_vars = [self._get_dataframe_var_name(t.tool_id) for t in upstream]
        return f"{var_name} = {input_vars[0]}.unionByName({', '.join(input_vars[1:])})\n"

    def _generate_sort_code(self, tool: ToolNode, var_name: str, input_var: str) -> str:
        """Generate code for Sort tool."""
        sort_columns = self._extract_sort_columns(tool)
        cols_str = ", ".join([f'col("{col}")' for col in sort_columns])
        return f"{var_name} = {input_var}.orderBy({cols_str})\n"

    def _generate_summarize_code(self, tool: ToolNode, var_name: str, input_var: str) -> str:
        """Generate code for Summarize tool (aggregations)."""
        group_by = self._extract_group_by_columns(tool)
        aggregations = self._extract_aggregations(tool)
        
        agg_calls = []
        for name, func in aggregations.items():
            agg_calls.append(f'{func}.alias("{name}")')
        agg_str = ", ".join(agg_calls)

        if group_by:
            group_str = ", ".join([f'"{col}"' for col in group_by])
            return f"""{var_name} = {input_var}.groupBy({group_str}).agg(
    {agg_str}
)
"""
        else:
            return f"""{var_name} = {input_var}.agg(
    {agg_str}
)
"""

    def _generate_unique_code(self, tool: ToolNode, var_name: str, input_var: str) -> str:
        """Generate code for Unique tool (remove duplicates)."""
        return f"{var_name} = {input_var}.distinct()\n"

    def _generate_sample_code(self, tool: ToolNode, var_name: str, input_var: str) -> str:
        """Generate code for Sample tool."""
        # Placeholder: assuming a simple fraction sample
        return f"{var_name} = {input_var}.sample(fraction=0.1, withReplacement=False)\n"

    def _generate_browse_code(self, tool: ToolNode, var_name: str, input_var: str) -> str:
        """Generate code for Browse tool (no-op in PySpark, used for caching/debug)."""
        # In a real scenario, this might trigger a .cache() or a .show()
        return f"# {var_name} = {input_var} # Browse tool - no-op in PySpark generation\n"

    def _generate_output_writing(self) -> str:
        """Generate code to write output data to files."""
        output_tools = self.workflow_ir.get_output_tools()
        code_lines = []

        if not output_tools:
            code_lines.append("\n# No output tools found in workflow\n")
            return "\n".join(code_lines)

        code_lines.append("\n# Write output data")
        code_lines.append("# " + "=" * 60)

        for tool in output_tools:
            upstream = self.workflow_ir.get_upstream_tools(tool.tool_id)
            if not upstream:
                code_lines.append(f"# WARNING: Output tool {tool.name} (ID: {tool.tool_id}) has no input.\n")
                continue

            input_var = self._get_dataframe_var_name(upstream[0].tool_id)
            
            # Placeholder for extracting output path and format
            output_path = f"'/tmp/output_{tool.tool_id}.parquet'"
            
            code_lines.append(f"""{input_var}.write.mode("overwrite").parquet({output_path})
# Output tool: {tool.name} (ID: {tool.tool_id})
""")
        
        return "\n".join(code_lines)
