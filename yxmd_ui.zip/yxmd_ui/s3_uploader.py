import boto3
import os
from typing import Optional

# Hardcoded S3 Configuration
S3_BUCKET_NAME = "yxmd-translator-uploads"
S3_REGION = "us-east-1" # Placeholder region

class S3Uploader:
    """
    Utility class to handle file uploads to a hardcoded S3 bucket.
    """
    def __init__(self):
        # Initialize S3 client. Assumes AWS credentials are set up in the environment
        # or via IAM roles if running on an EC2 instance.
        self.s3_client = boto3.client('s3', region_name=S3_REGION)
        self.bucket_name = S3_BUCKET_NAME

    def upload_file(self, file_path: str, s3_key_prefix: Optional[str] = None) -> Optional[str]:
        """
        Uploads a file to S3 and returns the S3 URI (s3://bucket/key).

        :param file_path: Local path to the file to upload.
        :param s3_key_prefix: Optional prefix for the S3 key (e.g., a user ID or session ID).
        :return: The S3 URI of the uploaded file, or None on failure.
        """
        if not os.path.exists(file_path):
            print(f"Error: Local file not found at {file_path}")
            return None

        file_name = os.path.basename(file_path)
        
        # Create a unique S3 key
        if s3_key_prefix:
            s3_key = f"{s3_key_prefix}/{file_name}"
        else:
            s3_key = file_name

        try:
            print(f"Uploading {file_name} to s3://{self.bucket_name}/{s3_key}...")
            self.s3_client.upload_file(file_path, self.bucket_name, s3_key)
            print("Upload successful.")
            
            # Return the S3 URI for use in PySpark code
            return f"s3://{self.bucket_name}/{s3_key}"

        except Exception as e:
            print(f"S3 Upload Error: {e}")
            return None

if __name__ == '__main__':
    # Example usage (requires a dummy file and configured AWS credentials)
    uploader = S3Uploader()
    
    # Create a dummy file for testing
    dummy_file_path = "dummy_input.csv"
    with open(dummy_file_path, "w") as f:
        f.write("col1,col2\n1,a\n2,b\n")
        
    s3_uri = uploader.upload_file(dummy_file_path, s3_key_prefix="test_session")
    
    if s3_uri:
        print(f"File uploaded to: {s3_uri}")
    
    os.remove(dummy_file_path)
