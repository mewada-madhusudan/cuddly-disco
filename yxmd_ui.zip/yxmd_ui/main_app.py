import sys
import os
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QFileDialog, QLabel, QLineEdit, QScrollArea,
    QGroupBox, QMessageBox
)
from PyQt6.QtCore import Qt, QTimer
from pathlib import Path
from typing import Dict, List, Optional

# Import backend components
sys.path.append(str(Path(__file__).parent / "backend"))
from yxmd_parser import YXMDParser, ToolNode, ToolType
from pyspark_generator import PySparKCodeGenerator
from s3_uploader import S3Uploader

# Global hardcoded S3 key prefix for this session
S3_KEY_PREFIX = "session_12345" 

class YXMDTranslatorApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("YXMD to PySpark Translator UI")
        self.setGeometry(100, 100, 800, 600)

        self.workflow_ir = None
        self.input_tools: List[ToolNode] = []
        self.input_file_paths: Dict[str, str] = {} # {tool_id: local_file_path}
        self.s3_uris: Dict[str, str] = {} # {tool_id: s3_uri}
        self.s3_uploader = S3Uploader()

        self._create_widgets()
        self._setup_layout()

    def _create_widgets(self):
        # --- Workflow Selection ---
        self.yxmd_path_label = QLabel("No YXMD file selected.")
        self.select_yxmd_button = QPushButton("Select YXMD File")
        self.select_yxmd_button.clicked.connect(self.select_yxmd_file)

        # --- Input Mapping Area ---
        self.input_group = QGroupBox("Workflow Input Mapping")
        self.input_layout = QVBoxLayout()
        self.input_group.setLayout(self.input_layout)
        
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setWidget(self.input_group)
        self.scroll_area.setFixedHeight(300)

        # --- Action Buttons ---
        self.upload_button = QPushButton("Upload All Files to S3")
        self.upload_button.clicked.connect(self.upload_all_to_s3)
        self.upload_button.setEnabled(False)
        
        self.generate_button = QPushButton("Generate PySpark Code")
        self.generate_button.clicked.connect(self.generate_pyspark_code)
        self.generate_button.setEnabled(False)

        # --- Output Area ---
        self.output_path_label = QLabel("Output PySpark file path:")
        self.output_path_edit = QLineEdit("output.py")
        self.output_path_edit.setPlaceholderText("Enter path to save generated PySpark code")

    def _setup_layout(self):
        central_widget = QWidget()
        main_layout = QVBoxLayout()

        # Workflow Selection Layout
        yxmd_layout = QHBoxLayout()
        yxmd_layout.addWidget(self.select_yxmd_button)
        yxmd_layout.addWidget(self.yxmd_path_label)
        main_layout.addLayout(yxmd_layout)

        # Input Mapping Scroll Area
        main_layout.addWidget(self.scroll_area)

        # Output Path Layout
        output_layout = QHBoxLayout()
        output_layout.addWidget(self.output_path_label)
        output_layout.addWidget(self.output_path_edit)
        main_layout.addLayout(output_layout)

        # Action Buttons Layout
        action_layout = QHBoxLayout()
        action_layout.addWidget(self.upload_button)
        action_layout.addWidget(self.generate_button)
        main_layout.addLayout(action_layout)

        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

    def select_yxmd_file(self):
        """Opens a file dialog to select the YXMD file."""
        file_name, _ = QFileDialog.getOpenFileName(self, "Select Alteryx YXMD File", "", "Alteryx Workflow Files (*.yxmd)")
        if file_name:
            self.yxmd_path_label.setText(f"Selected: {file_name}")
            self.parse_yxmd_file(file_name)

    def parse_yxmd_file(self, yxmd_path: str):
        """Parses the YXMD file and populates the input mapping area."""
        try:
            parser = YXMDParser(yxmd_path)
            self.workflow_ir = parser.parse()
            
            # Filter for tools that require a file input
            self.input_tools = [
                tool for tool in self.workflow_ir.tools.values() 
                if tool.tool_type in [ToolType.INPUT_DATA, ToolType.TEXT_INPUT]
            ]
            
            self.input_file_paths.clear()
            self.s3_uris.clear()
            self.populate_input_mapping()
            
            self.upload_button.setEnabled(bool(self.input_tools))
            self.generate_button.setEnabled(False)
            
            QMessageBox.information(self, "Success", f"Workflow '{self.workflow_ir.name}' parsed successfully. Found {len(self.input_tools)} input tools.")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to parse YXMD file: {e}")
            self.workflow_ir = None
            self.input_tools = []
            self.upload_button.setEnabled(False)
            self.generate_button.setEnabled(False)

    def populate_input_mapping(self):
        """Clears and repopulates the input mapping layout with widgets for each input tool."""
        # Clear existing widgets
        for i in reversed(range(self.input_layout.count())): 
            widget = self.input_layout.itemAt(i).widget()
            if widget is not None:
                widget.deleteLater()

        if not self.input_tools:
            self.input_layout.addWidget(QLabel("No file input tools found in the workflow."))
            return

        for tool in self.input_tools:
            tool_id = tool.tool_id
            
            # Tool Label
            tool_label = QLabel(f"Tool {tool_id} ({tool.name} - {tool.tool_type.name}):")
            
            # File Path Input and Button
            file_select_layout = QHBoxLayout()
            file_path_edit = QLineEdit()
            file_path_edit.setPlaceholderText("Select local input file...")
            file_path_edit.textChanged.connect(lambda text, tid=tool_id: self.update_input_path(tid, text))
            
            select_file_btn = QPushButton("Browse")
            select_file_btn.clicked.connect(lambda checked, tid=tool_id, edit=file_path_edit: self.select_input_file(tid, edit))
            
            file_select_layout.addWidget(file_path_edit)
            file_select_layout.addWidget(select_file_btn)
            
            # S3 Status Label
            s3_status_label = QLabel("S3 Status: Not Uploaded")
            s3_status_label.setObjectName(f"s3_status_{tool_id}") # Use object name for easy lookup
            
            # Add to main input layout
            tool_widget = QWidget()
            tool_widget_layout = QVBoxLayout()
            tool_widget_layout.addWidget(tool_label)
            tool_widget_layout.addLayout(file_select_layout)
            tool_widget_layout.addWidget(s3_status_label)
            tool_widget.setLayout(tool_widget_layout)
            
            self.input_layout.addWidget(tool_widget)

    def update_input_path(self, tool_id: str, path: str):
        """Updates the internal dictionary when a file path is manually entered."""
        self.input_file_paths[tool_id] = path
        # Reset S3 status when path changes
        self.s3_uris.pop(tool_id, None)
        self.update_s3_status_label(tool_id, "Not Uploaded")
        self.generate_button.setEnabled(False)

    def select_input_file(self, tool_id: str, line_edit: QLineEdit):
        """Opens a file dialog for a specific input tool."""
        file_name, _ = QFileDialog.getOpenFileName(self, f"Select Input File for Tool {tool_id}", "", "All Files (*)")
        if file_name:
            line_edit.setText(file_name)
            self.input_file_paths[tool_id] = file_name
            # Reset S3 status when path changes
            self.s3_uris.pop(tool_id, None)
            self.update_s3_status_label(tool_id, "Not Uploaded")
            self.generate_button.setEnabled(False)

    def update_s3_status_label(self, tool_id: str, status: str):
        """Updates the S3 status label for a given tool ID."""
        label = self.findChild(QLabel, f"s3_status_{tool_id}")
        if label:
            label.setText(f"S3 Status: {status}")
            if status.startswith("s3://"):
                label.setStyleSheet("color: green")
            elif "Error" in status:
                label.setStyleSheet("color: red")
            else:
                label.setStyleSheet("color: black")

    def upload_all_to_s3(self):
        """Iterates through all selected input files and uploads them to S3."""
        if not self.workflow_ir:
            QMessageBox.warning(self, "Warning", "Please select and parse a YXMD file first.")
            return

        all_uploaded = True
        for tool in self.input_tools:
            tool_id = tool.tool_id
            local_path = self.input_file_paths.get(tool_id)

            if not local_path or not os.path.exists(local_path):
                QMessageBox.warning(self, "Missing File", f"Local file not selected or found for Tool {tool_id} ({tool.name}). Skipping upload.")
                all_uploaded = False
                continue

            self.update_s3_status_label(tool_id, "Uploading...")
            QApplication.processEvents() # Force UI update

            # Perform the upload
            s3_uri = self.s3_uploader.upload_file(local_path, s3_key_prefix=S3_KEY_PREFIX)

            if s3_uri:
                self.s3_uris[tool_id] = s3_uri
                self.update_s3_status_label(tool_id, s3_uri)
            else:
                self.s3_uris.pop(tool_id, None)
                self.update_s3_status_label(tool_id, "Upload Error")
                all_uploaded = False

        if all_uploaded and self.s3_uris:
            self.generate_button.setEnabled(True)
            QMessageBox.information(self, "Success", "All required input files have been successfully uploaded to S3.")
        else:
            self.generate_button.setEnabled(False)
            QMessageBox.warning(self, "Partial Success/Failure", "Some files failed to upload or were missing. Please check the status.")

    def generate_pyspark_code(self):
        """Generates the PySpark code using the S3 URIs for input paths."""
        if not self.workflow_ir:
            QMessageBox.warning(self, "Warning", "Please select and parse a YXMD file first.")
            return
        
        if not self.s3_uris or len(self.s3_uris) != len(self.input_tools):
            QMessageBox.warning(self, "Warning", "Please ensure all input files are selected and successfully uploaded to S3.")
            return

        try:
            # 1. Update the workflow IR with the S3 URIs
            # This is a simplified way to pass the S3 paths to the generator
            # In a real scenario, we'd update the tool configuration in the IR
            # For this implementation, we'll pass the mapping to the generator
            
            # 2. Generate the code
            # We need to modify PySparKCodeGenerator to accept the S3 mapping
            # For now, we'll assume the generator is updated to handle this
            
            # NOTE: The current PySparKCodeGenerator does not accept the S3 mapping yet.
            # We will update it in the next phase. For now, we'll simulate the call.
            
            # Generate the code, passing the S3 URIs
            generator = PySparKCodeGenerator(
                workflow_ir=self.workflow_ir,
                input_files=self.s3_uris,
                spark_app_name=self.workflow_ir.name # Use workflow name as app name
            )
            
            code = generator.generate()
            
            # 3. Save the output
            output_path = self.output_path_edit.text()
            if not output_path:
                output_path = "output.py"
            
            with open(output_path, "w") as f:
                f.write(code)
            
            QMessageBox.information(self, "Success", f"PySpark code generated successfully and saved to: {output_path}")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to generate PySpark code: {e}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = YXMDTranslatorApp()
    window.show()
    sys.exit(app.exec())
