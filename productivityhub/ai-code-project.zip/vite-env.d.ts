/// <reference types="vite/client" />
