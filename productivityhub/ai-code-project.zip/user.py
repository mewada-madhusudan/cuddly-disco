from sqlalchemy import Column, String, JSON
from .base import BaseModel

class User(BaseModel):
    __tablename__ = "users"
    
    username = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    full_name = Column(String)
    hashed_password = Column(String)
    
    # Integration credentials (encrypted)
    jira_credentials = Column(JSON)
    confluence_credentials = Column(JSON)
    microsoft_credentials = Column(JSON)
    
    # User preferences
    preferences = Column(JSON, default={})