from fastapi import APIRouter, HTTPException
from typing import List
import logging

logger = logging.getLogger(__name__)

router = APIRouter()

@router.get("/")
async def get_local_projects():
    """Get local development projects"""
    try:
        # Mock data for demonstration
        mock_projects = [
            {
                "id": "1",
                "name": "productivity-hub",
                "path": "/Users/alex/Projects/productivity-hub",
                "type": "Node.js",
                "lastModified": "2025-12-04T12:00:00Z",
                "gitBranch": "feature/dashboard-ui",
                "hasUncommittedChanges": True,
                "hasUnpushedCommits": False,
                "category": "active"
            },
            {
                "id": "2",
                "name": "api-gateway",
                "path": "/Users/alex/Projects/api-gateway",
                "type": "Python",
                "lastModified": "2025-12-03T18:30:00Z",
                "gitBranch": "main",
                "hasUncommittedChanges": False,
                "hasUnpushedCommits": True,
                "category": "active"
            },