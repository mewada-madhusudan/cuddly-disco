import { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, FileText, File, Presentation, Table, Folder, Clock } from 'lucide-react';
import SectionCard from '@/components/ui/section-card';
import { MicrosoftFile } from '@/types';

// Mock data for demonstration
const mockMicrosoftFiles: MicrosoftFile[] = [
  {
    id: '1',
    name: 'Project Requirements.docx',
    type: 'Word',
    lastModified: '2025-12-04T11:20:00Z',
    lastAccessed: '2025-12-04T11:25:00Z',
    location: 'OneDrive/Projects',
    size: 2048576,
    url: 'https://company-my.sharepoint.com/personal/user/Documents/Project%20Requirements.docx'
  },
  {
    id: '2',
    name: 'Budget Analysis Q4.xlsx',
    type: 'Excel',
    lastModified: '2025-12-03T16:45:00Z',
    lastAccessed: '2025-12-04T09:30:00Z',
    location: 'SharePoint/Finance',
    size: 1536000,
    url: 'https://company.sharepoint.com/sites/finance/Documents/Budget%20Analysis%20Q4.xlsx'
  },
  {
    id: '3',
    name: 'Team Presentation.pptx',
    type: 'PowerPoint',
    lastModified: '2025-12-02T14:15:00Z',
    lastAccessed: '2025-12-03T10:00:00Z',
    location: 'OneDrive/Presentations',
    size: 5242880,