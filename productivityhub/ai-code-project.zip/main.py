from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
from contextlib import asynccontextmanager
import logging

from app.api import auth, jira, confluence, microsoft, projects, search, settings
from app.core.database import init_db
from app.core.scheduler import start_scheduler, stop_scheduler

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    # Startup
    logger.info("Starting Productivity Hub Backend...")
    await init_db()
    start_scheduler()
    yield
    # Shutdown
    logger.info("Shutting down Productivity Hub Backend...")
    stop_scheduler()

# Create FastAPI application
app = FastAPI(
    title="Productivity Hub API",
    description="Unified workspace dashboard API aggregating Jira, Confluence, Microsoft 365, and local projects",
    version="1.0.0",
    lifespan=lifespan
)

# Configure CORS