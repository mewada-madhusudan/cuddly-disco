import httpx
from typing import List, Optional
from datetime import datetime
import logging
from app.models.jira import JiraTicket
from app.core.database import AsyncSessionLocal
from sqlalchemy import select

logger = logging.getLogger(__name__)

class JiraService:
    def __init__(self):
        self.base_url = None
        self.auth_token = None
        self.username = None
    
    def configure(self, base_url: str, username: str, auth_token: str):
        """Configure Jira connection"""
        self.base_url = base_url.rstrip('/')
        self.username = username
        self.auth_token = auth_token
    
    async def test_connection(self) -> bool:
        """Test Jira connection"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.base_url}/rest/api/3/myself",
                    auth=(self.username, self.auth_token),
                    timeout=10.0
                )
                return response.status_code == 200
        except Exception as e:
            logger.error(f"Jira connection test failed: {e}")
            return False
    