import { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, FileText, Clock, Eye } from 'lucide-react';
import SectionCard from '@/components/ui/section-card';
import { ConfluencePage } from '@/types';

// Mock data for demonstration
const mockConfluencePages: ConfluencePage[] = [
  {
    id: '1',
    title: 'API Documentation - Authentication Flow',
    space: 'Engineering',
    lastModified: '2025-12-04T09:15:00Z',
    lastVisited: '2025-12-04T10:30:00Z',
    excerpt: 'Complete guide to implementing OAuth 2.0 authentication in our productivity hub application...',
    url: 'https://company.atlassian.net/wiki/spaces/ENG/pages/123456',
    type: 'created'
  },
  {
    id: '2',
    title: 'Project Requirements - Productivity Hub',
    space: 'Product',
    lastModified: '2025-12-03T14:20:00Z',
    lastVisited: '2025-12-04T08:45:00Z',
    excerpt: 'Detailed requirements document outlining the features and functionality of the productivity hub...',
    url: 'https://company.atlassian.net/wiki/spaces/PROD/pages/789012',
    type: 'visited'
  },
  {
    id: '3',
    title: 'Team Meeting Notes - December 2025',
    space: 'Engineering',
    lastModified: '2025-12-02T16:30:00Z',
    excerpt: 'Weekly team sync notes covering progress updates, blockers, and upcoming milestones...',
    url: 'https://company.atlassian.net/wiki/spaces/ENG/pages/345678',
    type: 'created'