from sqlalchemy import Column, String, Integer, DateTime, JSON, ForeignKey
from sqlalchemy.orm import relationship
from .base import BaseModel

class JiraTicket(BaseModel):
    __tablename__ = "jira_tickets"
    
    user_id = Column(Integer, ForeignKey("users.id"))
    
    # Jira specific fields
    jira_key = Column(String, index=True)
    jira_id = Column(String, index=True)
    title = Column(String)
    status = Column(String)
    priority = Column(String)
    project_name = Column(String)
    project_key = Column(String)
    assignee = Column(String)
    reporter = Column(String)
    
    # Dates
    due_date = Column(DateTime(timezone=True))
    last_updated = Column(DateTime(timezone=True))
    
    # URLs and metadata
    url = Column(String)
    description = Column(String)
    labels = Column(JSON, default=[])
    components = Column(JSON, default=[])
    
    # Relationship
    user = relationship("User")