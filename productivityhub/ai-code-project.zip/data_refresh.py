import logging
from typing import List
from app.services.jira_service import jira_service

logger = logging.getLogger(__name__)

class DataRefreshService:
    """Service for refreshing data from all integrations"""
    
    def __init__(self):
        self.is_refreshing = False
    
    async def refresh_all_data(self):
        """Refresh data from all configured integrations"""
        if self.is_refreshing:
            logger.info("Data refresh already in progress, skipping...")
            return
        
        try:
            self.is_refreshing = True
            logger.info("Starting data refresh for all integrations...")
            
            # TODO: Get list of active users and their settings
            # For now, just log the refresh attempt
            
            await self._refresh_jira_data()
            await self._refresh_confluence_data()
            await self._refresh_microsoft_data()
            
            logger.info("Data refresh completed successfully")
        except Exception as e:
            logger.error(f"Error during data refresh: {e}")
        finally:
            self.is_refreshing = False
    
    async def _refresh_jira_data(self):