import { useState, useCallback } from 'react';
import Header from '@/components/layout/Header';
import JiraSection from './JiraSection';
import ConfluenceSection from './ConfluenceSection';
import MicrosoftSection from './MicrosoftSection';
import ProjectsSection from './ProjectsSection';
import SettingsPanel from '@/components/settings/SettingsPanel';

export default function Dashboard() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<string>(new Date().toISOString());

  const handleSearch = useCallback((query: string) => {
    setSearchQuery(query);
    // TODO: Implement search filtering across all sections
  }, []);

  const handleRefresh = useCallback(async () => {
    setIsRefreshing(true);
    // TODO: Implement refresh logic for all sections
    setTimeout(() => {
      setIsRefreshing(false);
      setLastUpdated(new Date().toISOString());
    }, 2000);
  }, []);

  const handleSettingsClick = useCallback(() => {
    setShowSettings(true);
  }, []);

  const handleSettingsClose = useCallback(() => {
    setShowSettings(false);
  }, []);
