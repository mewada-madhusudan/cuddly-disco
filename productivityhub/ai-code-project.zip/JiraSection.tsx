import { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ExternalLink, Calendar, User, ArrowUp, ArrowDown, Minus } from 'lucide-react';
import SectionCard from '@/components/ui/section-card';
import { JiraTicket } from '@/types';

// Mock data for demonstration
const mockJiraTickets: JiraTicket[] = [
  {
    id: '1',
    key: 'PROD-123',
    title: 'Implement user authentication system',
    status: 'In Progress',
    priority: 'High',
    project: 'Productivity Hub',
    assignee: 'Alex Developer',
    dueDate: '2025-12-10',
    lastUpdated: '2025-12-04T10:30:00Z',
    url: 'https://company.atlassian.net/browse/PROD-123'
  },
  {
    id: '2',
    key: 'PROD-124',
    title: 'Fix dashboard loading performance',
    status: 'To Do',
    priority: 'Medium',
    project: 'Productivity Hub',
    assignee: 'Alex Developer',
    lastUpdated: '2025-12-03T15:45:00Z',
    url: 'https://company.atlassian.net/browse/PROD-124'
  },
  {
    id: '3',
    key: 'PROD-125',
    title: 'Add dark mode toggle',