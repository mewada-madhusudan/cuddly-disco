from sqlalchemy import Column, String, Integer, DateTime, Boolean, JSON, ForeignKey
from sqlalchemy.orm import relationship
from .base import BaseModel

class LocalProject(BaseModel):
    __tablename__ = "local_projects"
    
    user_id = Column(Integer, ForeignKey("users.id"))
    
    # Project basic info
    name = Column(String, index=True)
    path = Column(String)
    project_type = Column(String)  # Git, Node.js, Python, Java, Other
    
    # Git information
    git_branch = Column(String)
    has_uncommitted_changes = Column(Boolean, default=False)
    has_unpushed_commits = Column(Boolean, default=False)
    git_remote_url = Column(String)
    
    # Project metadata
    last_modified = Column(DateTime(timezone=True))
    category = Column(String)  # active, recent, inactive
    
    # Configuration files detected
    config_files = Column(JSON, default=[])
    
    # IDE preferences
    preferred_ide = Column(String)
    
    # Relationship
    user = relationship("User")