from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
import logging

logger = logging.getLogger(__name__)

router = APIRouter()

@router.get("/")
async def search_across_platforms(
    q: str = Query(..., description="Search query"),
    platforms: Optional[List[str]] = Query(None, description="Platforms to search in"),
    limit: int = Query(50, description="Maximum number of results")
):
    """Search across all integrated platforms"""
    try:
        # Mock search results for demonstration
        mock_results = []
        
        if not platforms or "jira" in platforms:
            if "auth" in q.lower() or "implement" in q.lower():
                mock_results.append({
                    "id": "jira-1",
                    "platform": "jira",
                    "type": "ticket",
                    "title": "Implement user authentication system",
                    "excerpt": "Complete implementation of OAuth 2.0 authentication flow...",
                    "url": "https://company.atlassian.net/browse/PROD-123",
                    "lastUpdated": "2025-12-04T10:30:00Z"
                })
        
        if not platforms or "confluence" in platforms:
            if "api" in q.lower() or "documentation" in q.lower():
                mock_results.append({
                    "id": "confluence-1",
                    "platform": "confluence",