from sqlalchemy import Column, String, Integer, Boolean, JSON, ForeignKey
from sqlalchemy.orm import relationship
from .base import BaseModel

class UserSettings(BaseModel):
    __tablename__ = "user_settings"
    
    user_id = Column(Integer, ForeignKey("users.id"), unique=True)
    
    # General preferences
    theme = Column(String, default="dark")
    refresh_interval = Column(Integer, default=5)  # minutes
    auto_refresh = Column(Boolean, default=True)
    
    # Integration settings
    integrations_enabled = Column(JSON, default={
        "jira": True,
        "confluence": True,
        "microsoft": False,
        "local_projects": True
    })
    
    # Project settings
    project_root_path = Column(String)
    preferred_ide = Column(String, default="vscode")
    
    # Notification settings
    notifications_enabled = Column(Boolean, default=True)
    notification_types = Column(JSON, default=[])
    
    # Dashboard layout
    dashboard_layout = Column(JSON, default={})
    
    # Relationship
    user = relationship("User", uselist=False)