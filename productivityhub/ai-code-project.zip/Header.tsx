import { Search, Settings, RefreshCw, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

interface HeaderProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onRefresh: () => void;
  onSettingsClick: () => void;
  isRefreshing: boolean;
  lastUpdated?: string;
}

export default function Header({
  searchQuery,
  onSearchChange,
  onRefresh,
  onSettingsClick,
  isRefreshing,
  lastUpdated
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-800 bg-slate-950/95 backdrop-blur supports-[backdrop-filter]:bg-slate-950/60">
      <div className="container flex h-16 items-center justify-between px-6">
        {/* Logo and Title */}
        <div className="flex items-center space-x-3">
          <img 
            src="/assets/productivity-logo.png" 
            alt="Productivity Hub" 
            className="h-8 w-8"
          />
          <h1 className="text-xl font-bold text-slate-100">
            Productivity Hub
          </h1>
        </div>