// Core data types for the Productivity Hub

export interface JiraTicket {
  id: string;
  key: string;
  title: string;
  status: 'To Do' | 'In Progress' | 'Done' | 'Blocked';
  priority: 'Highest' | 'High' | 'Medium' | 'Low' | 'Lowest';
  project: string;
  assignee: string;
  dueDate?: string;
  lastUpdated: string;
  url: string;
}

export interface ConfluencePage {
  id: string;
  title: string;
  space: string;
  lastModified: string;
  lastVisited?: string;
  excerpt: string;
  url: string;
  type: 'created' | 'visited';
}

export interface MicrosoftFile {
  id: string;
  name: string;
  type: 'Word' | 'Excel' | 'PowerPoint' | 'OneDrive' | 'SharePoint';
  lastModified: string;
  lastAccessed: string;
  location: string;
  size: number;
  url: string;
}