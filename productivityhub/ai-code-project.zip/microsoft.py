from sqlalchemy import Column, String, Integer, DateTime, BigInteger, ForeignKey
from sqlalchemy.orm import relationship
from .base import BaseModel

class MicrosoftFile(BaseModel):
    __tablename__ = "microsoft_files"
    
    user_id = Column(Integer, ForeignKey("users.id"))
    
    # Microsoft specific fields
    microsoft_id = Column(String, index=True)
    name = Column(String)
    file_type = Column(String)  # Word, Excel, PowerPoint, OneDrive, SharePoint
    
    # File metadata
    size = Column(BigInteger)
    location = Column(String)
    parent_path = Column(String)
    
    # Dates
    last_modified = Column(DateTime(timezone=True))
    last_accessed = Column(DateTime(timezone=True))
    
    # URLs
    web_url = Column(String)
    download_url = Column(String)
    
    # Relationship
    user = relationship("User")