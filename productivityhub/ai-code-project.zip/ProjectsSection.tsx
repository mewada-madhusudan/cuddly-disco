import { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, Folder, GitBranch, AlertCircle, Terminal, Code, Clock } from 'lucide-react';
import SectionCard from '@/components/ui/section-card';
import { LocalProject } from '@/types';

// Mock data for demonstration
const mockProjects: LocalProject[] = [
  {
    id: '1',
    name: 'productivity-hub',
    path: '/Users/alex/Projects/productivity-hub',
    type: 'Node.js',
    lastModified: '2025-12-04T12:00:00Z',
    gitBranch: 'feature/dashboard-ui',
    hasUncommittedChanges: true,
    hasUnpushedCommits: false,
    category: 'active'
  },
  {
    id: '2',
    name: 'api-gateway',
    path: '/Users/alex/Projects/api-gateway',
    type: 'Python',
    lastModified: '2025-12-03T18:30:00Z',
    gitBranch: 'main',
    hasUncommittedChanges: false,
    hasUnpushedCommits: true,
    category: 'active'
  },
  {
    id: '3',
    name: 'mobile-app',
    path: '/Users/alex/Projects/mobile-app',
    type: 'Git',
    lastModified: '2025-11-28T14:20:00Z',