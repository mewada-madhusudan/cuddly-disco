import { useState } from 'react';
import { X, Settings, Zap, Folder, Palette, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';

interface SettingsPanelProps {
  onClose: () => void;
}

export default function SettingsPanel({ onClose }: SettingsPanelProps) {
  const [settings, setSettings] = useState({
    theme: 'dark',
    refreshInterval: 5,
    autoRefresh: true,
    integrations: {
      jira: true,
      confluence: true,
      microsoft: false,
      localProjects: true
    },
    projectRootPath: '/Users/alex/Projects',
    preferredIDE: 'vscode'
  });

  const handleIntegrationToggle = (integration: string, enabled: boolean) => {
    setSettings(prev => ({
      ...prev,
      integrations: {
        ...prev.integrations,
        [integration]: enabled