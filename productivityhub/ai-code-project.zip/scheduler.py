from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
import logging
from app.services.data_refresh import DataRefreshService

logger = logging.getLogger(__name__)

scheduler = AsyncIOScheduler()
data_refresh_service = DataRefreshService()

def start_scheduler():
    """Start the background scheduler"""
    try:
        # Schedule data refresh every 5 minutes
        scheduler.add_job(
            data_refresh_service.refresh_all_data,
            IntervalTrigger(minutes=5),
            id='refresh_all_data',
            name='Refresh all integration data',
            replace_existing=True
        )
        
        # Schedule project scan every 15 minutes
        scheduler.add_job(
            data_refresh_service.scan_projects,
            IntervalTrigger(minutes=15),
            id='scan_projects',
            name='Scan local projects',
            replace_existing=True
        )
        
        scheduler.start()
        logger.info("Background scheduler started")
    except Exception as e:
        logger.error(f"Failed to start scheduler: {e}")
