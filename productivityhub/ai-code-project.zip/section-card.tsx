import { ReactNode } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, ExternalLink, AlertCircle } from 'lucide-react';

interface SectionCardProps {
  title: string;
  icon: ReactNode;
  children: ReactNode;
  isLoading?: boolean;
  error?: string;
  lastUpdated?: string;
  itemCount?: number;
  onRefresh?: () => void;
  onViewAll?: () => void;
}

export default function SectionCard({
  title,
  icon,
  children,
  isLoading = false,
  error,
  lastUpdated,
  itemCount,
  onRefresh,
  onViewAll
}: SectionCardProps) {
  return (
    <Card className="bg-slate-900 border-slate-700 hover:border-slate-600 transition-colors">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2 text-slate-100">
            <span className="text-indigo-400">{icon}</span>
            <span className="text-lg font-semibold">{title}</span>