from sqlalchemy import Column, String, Integer, DateTime, Text, ForeignKey
from sqlalchemy.orm import relationship
from .base import BaseModel

class ConfluencePage(BaseModel):
    __tablename__ = "confluence_pages"
    
    user_id = Column(Integer, ForeignKey("users.id"))
    
    # Confluence specific fields
    confluence_id = Column(String, index=True)
    title = Column(String)
    space_key = Column(String)
    space_name = Column(String)
    
    # Content
    excerpt = Column(Text)
    content_type = Column(String, default="page")
    
    # Dates
    last_modified = Column(DateTime(timezone=True))
    last_visited = Column(DateTime(timezone=True))
    
    # URLs and metadata
    url = Column(String)
    page_type = Column(String)  # 'created' or 'visited'
    
    # Relationship
    user = relationship("User")